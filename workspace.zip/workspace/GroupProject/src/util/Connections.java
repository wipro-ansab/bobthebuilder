package util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connections {

	Connections conn = null;
			public static Connection Connect() throws SQLException {
				Connection conn = null;
				try {			
					conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl1","SCOTT","tiger");
					System.out.println("Connected");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					System.out.println("Failed to Connect");
				}
				return conn;		
			}
		}
