package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import util.*;
import dao.BillDAO;
import bean.BillBean;

public class Userinterface {

	public static void main(String[] args) throws SQLException {
		Connection conn = null;
		conn = Connections.Connect();
		//callInterface(conn);
		
		
		ArrayList<String> item = new ArrayList<String>();
		item.add("1");
		ArrayList<Integer> quantity = new ArrayList<Integer>();
		quantity.add(1);
		BillBean bill = new BillBean("6", quantity, item, "1");
		boolean billSys = BillDAO.insertBill(bill);
		
	}
	
	private static void callInterface(Connection conn) throws SQLException{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Welcome to Sainsburys");
		System.out.println("What would thou liketh doeth");
		System.out.println("Option 1: New Bill");
		System.out.println("Option 2: Update Stock");
		System.out.println("Option 3: List Stock");
		System.out.println("Option 4: Customer Details");
		System.out.println("Option 5: Customer Editing");
		
		int optionChoice = scanner.nextInt(); 
		
		switch(optionChoice){
			case 1: 
				
				break;
			case 2:
				updateStock(conn);
				break;
			case 3:
				listStock(conn);
				break;
			case 4:
				System.out.println("Please enter the customers name");
				String name = scanner.next();
				findCustomer(conn, name);
				break;
			case 5:
				break;
			default:
				System.out.println("That was an invalid choice");
				break;
		}
	}
	
	private static void updateStock(Connection conn) {
		
		
	}

	private static void listStock(Connection conn) throws SQLException {
		Statement listStock = conn.createStatement();
		String sqlList = "SELECT firstName, lastName FROM customer";
		ResultSet itemList = listStock.executeQuery(sqlList);
		
		
		while(itemList.next()){
			String fullName = itemList.getString("firstName");
			String job = itemList.getString("lastName");
			System.out.println("Name: " + fullName);
			System.out.println("Job: " + job);
			System.out.println();
		}
		
	}

	private static void findCustomer(Connection conn, String name) throws SQLException {
		PreparedStatement customerSearch = null;
		String sqlSearch = "SELECT ename FROM emp WHERE ename = ?";
		customerSearch = conn.prepareStatement(sqlSearch);
		customerSearch.setString(1, name);
		ResultSet customerNames = customerSearch.executeQuery();
				
		while(customerNames.next()){
			String fullName = customerNames.getString("ename");
			System.out.println(fullName);	
		}		
	}	
}

