package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import util.*;
import bean.BillBean;


public class BillDAO {
	static Connection conn = null;
	public static boolean insertBill (BillBean bill) throws SQLException 
	{
		conn = Connections.Connect();

		PreparedStatement createbill = null;
		String sqlinsert="enter details into system values(?,?,?,?,?,?)" ;
		createbill.setString(1, bill.getBillID());
		createbill.setString(2, bill.getPid());
		createbill.setInt(3, bill.getQuantity());
		createbill.setFloat(4, bill.getTotalPrice());
		createbill.setString(5, bill.getCusID());
		return false;

	}



//public BillBean readBillBean(String BillID){return null;}
public void selectAll() throws SQLException{
	ArrayList<BillBean> list=new ArrayList<BillBean>();
	
		//	Statement st=con.createStatement();
		//	Connection conn= conn.getConnection();
		String sql="select * from Bill WHERE billid = ?";
		PreparedStatement createbill=conn.prepareStatement(sql);
		createbill.setString(1,""  /*put something here*/);
		ResultSet rs=createbill.executeQuery(sql);

		while(rs.next())
		{
			BillBean bean=new BillBean();
			bean.setBillID(rs.getString("BillID"));
			bean.setPid(rs.getString("ProductID"));
			bean.setQuantity(rs.getInt("Quantity"));
			bean.setTotalPrice(rs.getFloat("Total price"));
			bean.setCusID(rs.getString("Customer ID"));
			list.add(bean);
		}
	}
}
