package logicbuilding;

public class Pin {
static int a = 123;
static int b = 456;
static int g = 789;


//int [] pin ={
int alpha =a/100;
int beta =b/10;
int gamma = g/
	public static void main(String[] args) {
		String pin = ""a/100;
System.out.println(pin);
	}
}
