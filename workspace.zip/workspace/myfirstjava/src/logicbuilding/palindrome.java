package logicbuilding;

import java.util.Scanner;

public class palindrome {public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner in = new Scanner(System.in);
	
	System.out.print("Enter a word :");
	String input = in.nextLine();
	

	String reversedWord = new StringBuilder(input).reverse().toString();
	
	if(input.equalsIgnoreCase(reversedWord)){
	System.out.println(input +"1");
	}
else{
		System.out.println("2");
}
}
}
