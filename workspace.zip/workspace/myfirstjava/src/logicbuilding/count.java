package logicbuilding;

import java.util.Scanner;

public class count {
	
	public static void main(String[] args) {
		int[] input2 = {2,3,4,6,3,4,2,1};
		longestIncreasingSeq(8, input2);
	}
	public static void longestIncreasingSeq(int input1, int[] input2){
		int count = 1;
		int max = 0;
		for(int i =1;i<input1;i++)
		{
			if(input2[i]<input2[i-1])
					{
				count++;
				if(count>max){
					max = count;
				}
					}
			else{
				count = 1;
			}
		}
		System.out.println(max);

	}
}
