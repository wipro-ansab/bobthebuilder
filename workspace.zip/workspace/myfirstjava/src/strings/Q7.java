package strings;

public class Q7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String a= "ab*cd";
String b= "*";
String c= "**";
if(a.contains(b))
		{
	System.out.println(a.substring(0, 1)+a.substring(4));
		}
if(a.contains(c))
{
System.out.println(a.substring(0, 1)+a.substring(4));
}
	}

}
