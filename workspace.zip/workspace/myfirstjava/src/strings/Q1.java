package strings;

import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		palindrome();

	}
public static void palindrome (){
	Scanner in = new Scanner(System.in);
	String palin;
	System.out.println("Enter a something");
	palin = in.next();
	
	
	String reverse; 
	reverse = new StringBuilder(palin).reverse().toString();
	if(palin.equals(reverse)){
		System.out.println("This is a palindrome");
	}else{
		System.out.println("This is not a palindrome");
	}
	}
}
