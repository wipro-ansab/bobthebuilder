package strings;

import java.util.Random;

import strings.Compartment;
import strings.FirstClass;
import strings.General;
import strings.Ladies;
import strings.Luggage;



public abstract class Testcompartment {
static int randomNum;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Compartment [] c = new Compartment[10];
		 randomNum = 1 + (int)(Math.random() * 4); 
		 //c = randomNum;
		 FirstClass F = new FirstClass ();
		 General G = new General();
		 Ladies L = new Ladies();
		 Luggage Lu = new Luggage();
		 switch(randomNum)
		 {
			 case 1:
				 F.notice();
				 break;
			 case 2:
				 G.notice();
				 break;
			 case 3:
				 L.notice();
				 break;
			 case 4:
				 Lu.notice();
				 break;
				 
		 }
	}

}
