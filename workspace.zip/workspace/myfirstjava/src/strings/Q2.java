package strings;

import java.util.LinkedHashSet;
import java.util.Set;

public class Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a ="mark";
		String b ="kate";
		String c = a;
		int L = b.length();
		while(L>0){
			String Conc = b.substring(0,L);
			if(a.endsWith(Conc))
			{
				c = a+b.substring(L);
				break;
			}
			L--;
		}
		System.out.println(c);
	}

}
