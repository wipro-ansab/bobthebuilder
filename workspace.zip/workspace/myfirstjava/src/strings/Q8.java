package strings;

public class Q8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String a = "Hellower";
String b = "World";
System.out.print(a.substring(0,1)+b.substring(0,1)+a.substring(1,2)+b.substring(1,2)+a.substring(2,3)+b.substring(2,3)+a.substring(3,4)+b.substring(3,4)+a.substring(4)+b.substring(4));
	}

}
