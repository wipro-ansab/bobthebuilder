package strings;

public class Q4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String word ="CatDog";
int length= word.length();
if(length % 2==0)
{
	System.out.println(word.substring(0,3));
}
else
	
{	
System.out.println("null");	
}
}

}
