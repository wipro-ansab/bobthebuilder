package strings;

public abstract class animal  {

}
