package strings;

import java.util.Scanner;

public class logic {
public static void key (int input1, int input2, int input3){
	String a = Integer.toString(input1);
	String b = Integer.toString(input2);
	String c = Integer.toString(input3);
	String d = new StringBuilder(a).reverse().toString();
	String e = new StringBuilder(b).reverse().toString();
	String f = new StringBuilder(c).reverse().toString();
	int input4 = Integer.parseInt(d);
	int input5 = Integer.parseInt(e);
	int input6 = Integer.parseInt(f);
	int sum = input4 + input5+ input6;
	
//	for(int i=0;i<arr.length;i++) {
//	    sum += Character.getNumericValue(arr[i]);
//	}
	System.out.println(sum);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
key(0, 22, 25);


	}

}
