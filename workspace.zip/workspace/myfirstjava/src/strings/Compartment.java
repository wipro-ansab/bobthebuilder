package strings;

public abstract class Compartment {
	String cata;
public Compartment()
{}	

public Compartment(String cata) {
		super();
	this.cata = cata;
	}


public String getcata() {
	return cata;
}


public void setCata(String cata) {
	//this.cata = cata;
}


public void notice()
{
	System.out.println("print one of the catagory");
}
}