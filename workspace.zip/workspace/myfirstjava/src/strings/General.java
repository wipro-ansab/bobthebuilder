package strings;

public class General extends Compartment
{
	public General(){}
	public General(String cata)
	{
		super(cata);
	}
public void notice()
{
String cata = "General";
System.out.println(cata);
}
}