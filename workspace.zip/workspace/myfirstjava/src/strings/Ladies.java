package strings;

public  class Ladies extends Compartment
	{
		public Ladies()
		{
			
		}
		public Ladies(String cata)
		{
			super(cata);
		}
	public void notice()
	{
	String cata = "Ladies";
	System.out.println(cata);
	}
	}

