package strings;

public class Luggage extends Compartment
{
	public Luggage()
	{}
	public Luggage(String cata)
	{
		super(cata);
	}
public void notice()
{
String cata = "Luggage";
System.out.println(cata);
}
}