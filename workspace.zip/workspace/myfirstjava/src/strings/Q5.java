package strings;

public class Q5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String word = "wipro";
String revword = word.substring(1, word.length()-1);
System.out.println(revword);
	}

}
