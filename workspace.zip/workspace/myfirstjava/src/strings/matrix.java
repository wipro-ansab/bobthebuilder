package strings;

public class matrix {

	public static void main(String[] args) {
		int [][]input1 = {{5,1,3}, {2,9,4}, {8,7,6}};
}
	public static int output1;
	public static void identifyHeavy(int[][] input1) {
    	int sumcorn = 0;
    	int sumcen= 0;
    	sumcorn = input1[0][0] + input1[0][2]+ input1[2][0]+ input1[2][2];
    	sumcen = input1[1][0] + input1[0][1]+ input1[1][2]+ input1[2][1];

    	if(sumcorn>sumcen){
    		output1 = 1;
    		System.out.println(+output1);
    	}
    	if(sumcorn<sumcen){
    		output1 = 2;
    		System.out.println(+output1);
    	}
    	if(sumcorn==sumcen){
    		output1 = 3;
    		System.out.println(+output1);
    	}
    		}

    }