package strings;

public class Q3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String word = "Wipro";
String rep = word.substring(0,2);
for (int i = 0; i<word.length();i++)
{
System.out.print(rep);

	}

}
}