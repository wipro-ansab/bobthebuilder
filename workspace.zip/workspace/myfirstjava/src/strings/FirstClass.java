package strings;

public class FirstClass extends Compartment
{
	public FirstClass() {}
	public FirstClass(String cata)
	{
		super(cata);
	}
	public void notice()
	{
		String cata = "FirstClass";
		System.out.println(cata);
	}
}
