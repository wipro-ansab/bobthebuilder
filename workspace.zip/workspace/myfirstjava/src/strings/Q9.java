package strings;

import java.util.Scanner;

public class Q9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input1;
		int n;
		Scanner in = new Scanner(System.in);
		System.out.println("enter a string");
		input1 =in.next();
		System.out.println("enter a number");
		n = in.nextInt();
		if(n>input1.length())
		{
			System.out.println("enter an integer between 0 and length of String");
		}

		String a = input1.substring(input1.length()-n, input1.length());
		for (int i = 0; i<n;i++)
		{
		System.out.print(a);

	
		{
			
		}
		}
	}
}
