package strings;

public class Q6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String word = "xHix";
if(word.charAt(0)==word.charAt(word.length()-1)){
	System.out.println(word.substring(1, 3));
	}

}
}
