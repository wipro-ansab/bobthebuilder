package interfaces;

public interface LibraryUser {

}
