package myfirstjava;

import java.util.Scanner;

public class question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter a number");
		int one = in.nextInt();
		
		if( one <  0 ){
			System.out.print("negative");
		}
		else if( one >  0){
			System.out.print("positive");
		}
		else if( one ==  0){
			System.out.print("0");
		}
	}
	

}
