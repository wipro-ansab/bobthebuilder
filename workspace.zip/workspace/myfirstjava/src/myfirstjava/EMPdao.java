package myfirstjava;

public class EMPdao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String url="jdbc:oracle:thin:@localhost:1521:orcl1";
		DriverManager.getconnection(url, uname,pwd);
	}

}
