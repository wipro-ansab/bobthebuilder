package myfirstjava;
import java.util.Scanner;
public class digisum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
 String label;
 int outlabel;
 char c;
 System.out.println("enter large label");
 label = in.nextLine();
 char [] c_arr = label.toCharArray();
 if(c_arr.length)
}
}