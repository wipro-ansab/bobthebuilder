package myfirstjava;

public class question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x = args[0];
		String y = args[1];
if (x.equals(y)){
		System.out.println("same");
	}
else{
	System.out.println("not the same");
}
}
}