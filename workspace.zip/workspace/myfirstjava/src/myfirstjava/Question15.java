package myfirstjava;

import java.util.Arrays;

public class Question15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] duparray = {1,1,7,2,7,3,3,4,5,6,8};
		int count =1;
		Arrays.sort(duparray);
/*array above*/
		

		System.out.println();
	}

}
