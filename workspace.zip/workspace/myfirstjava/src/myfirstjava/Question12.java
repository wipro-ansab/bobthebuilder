package myfirstjava;

import java.util.Scanner;

public class Question12 {



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int option = 0;
		String choice = "n";
		Scanner scanoption = new Scanner(System.in);
		do{
			
			System.out.println("1.Add");
			System.out.println("2.Sub");
			option = scanoption.nextInt();
			if(option==1){
				Scanner in = new Scanner(System.in);
				System.out.println("enter first integer");
				int x = in.nextInt();
				System.out.println("enter second integer");
				int y = in.nextInt();
				int sum = x + y;
				System.out.println(+sum);
			}		
			if(option==2){
				Scanner it = new Scanner(System.in);
				System.out.println("enter first integer");
				int a = it.nextInt();
				System.out.println("enter second integer");
				int b = it.nextInt();
				int diff = a - b;
				System.out.println(+diff);
			}
			Scanner cont = new Scanner(System.in);
			choice = cont.nextLine();
		}while(choice.equals("y"));
		
	
	}

}
