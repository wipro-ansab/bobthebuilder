package myfirstjava;

import java.util.Scanner;

public class student {


			public class Student {

				// below is all encapsulated (inside the class) 
				
					// member variables / attributes / properties / instance variables 
					String name;
					int id;
					float m1;
					float m2;
					float m3;
					String result; 
					
					// member functions / instance functions 
					
					// read attribute values
					void getDetails(){
						
						Scanner scanner = new Scanner(System.in);
						
						System.out.println("Enter name, id, m1, m2, m3");
							
						/* name = scanner.nextLine();
						id = Integer.parseInt(scanner.next);
						m1 = Float.parseFloat(scanner.next());
						m2 = Float.parseFloat(scanner.next());
						m3 = Float.parseFloat(scanner.next());
						*/
						
						name = scanner.nextLine();
						id = scanner.nextInt();
						m1 = scanner.nextFloat();
						m2 = scanner.nextFloat();
						m3 = scanner.nextFloat();
						
					}
					
					// compute the result
					void computeResult(){
						
						float total = m1+m2+m3;
						
						if (total > 240) {
							result = "Pass";
						} else {
							result = "fail";
						}
							
					}
					
					// display results
					void display() {
						
						System.out.println("Name: " + name);
						System.out.println("id: " + id);
						System.out.println("m1= " + m1);
						System.out.println("m2= " + m2);
						System.out.println("m3= " + m3);
						System.out.println("Result= " + result);

				}
			} 
			 

	}

}
