package myfirstjava;

public class division {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
