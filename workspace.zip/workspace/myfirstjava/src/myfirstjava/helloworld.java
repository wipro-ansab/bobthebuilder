package myfirstjava;

import java.util.Scanner;

public class helloworld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
	
System.out.print("enter a number 1");
int one = in.nextInt();
/* reads the value of the first number*/

System.out.print("enter a number 2");
int two =in.nextInt();
/* reads the second number that was entered*/
int sum = one + two;
/* takes the sum of the two numbers*/
System.out.print("The  sum is " +sum);
	}

}
