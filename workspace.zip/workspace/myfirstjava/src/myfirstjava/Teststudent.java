package myfirstjava;

public class Teststudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student john = new Student(); 
		// to call, object.function(); 
		john.getDetails();
		john.computeResult();
		john.display();
		
		Student peter = new Student(); 
		// to call, object.function(); 
		peter.getDetails();
		peter.computeResult();
		peter.display();
	}

}
