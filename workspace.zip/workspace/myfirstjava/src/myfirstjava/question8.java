package myfirstjava;

public class question8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x = args [0];
		int y =Integer.parseInt(args[1]);
		if(x.equals("Male")){
			if(1<=y && y<=60){
				System.out.print("interest rate is 9.2%");
			}
			else if(61<=y && y<=120){
				System.out.print("interest rate is 8.3%");
		}
		}
		if(x.equals("female")){
				if(1<=y && y<=58){
					System.out.print("interest rate is 8.2%");
				}
					else if(59<=y && y<=120){
					System.out.print("interest rate is 7.6%");
					}
				}
		}
}
