package myfirstjava;

public class question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = Integer.parseInt(args[0]);
		int y = Integer.parseInt(args[1]);
		int z = x + y;
		
		System.out.print("the sum of " +x);
		System.out.print(" and " +y);
		System.out.print(" is " +z);
		
	}

}
