package myfirstjava;

public class question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x = args [0];
		String y = args [1];
		String z = new StringBuilder(y).reverse().toString();
		String w = x + z;
		System.out.println(w);
	}

}
