package myfirstjava;

public class Newsquare {
	int side;
	static int cnt;
	Square(int side)
	{
		this.side=side;
		cnt++;
	}

	public int getSide() {
		return side;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Square s1=new Square(10);
 System.out.println(Square.cnt);
 Square s2=new Square(20);
 System.out.println(Square.cnt);
 Square s3=new Square(30);
System.out.println(Square.cnt);
	}

}
