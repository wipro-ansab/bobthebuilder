package myfirstjava;

import java.util.Scanner;

public class question10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		
		System.out.print("Enter Number :");
		int input;
		int r;
		int sum = 0;
		int store;
		
		try{input = in.nextInt();
		}
		catch(Exception e){System.out.print("Invalid Input, Please enter an integer");
		return;}
		store = input;
		while(store>0){
			r=store%10;
			sum=(sum*10)+r;
			store=store/10;
			
		}
		if(input==sum){
		System.out.println(input +" is a palindrome");
		}
		else{
			System.out.println(input +" is not a palindrome");
		}
	}

}
