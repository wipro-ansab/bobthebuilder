package myfirstjava;

public class Question13 {
	

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
int x[]= new int[5];
x[0] = 7;
x[1] = 5;
x[2] = 2;
x[3] = 9;
x[4] = 3;

int max = getMax(x);
System.out.println("Maximum Value is: "+max);

// Calling getMin() method for getting min value
int min = getMin(x);
System.out.println("Minimum Value is: "+min);
}

// Method for getting the maximum value
public static int getMax(int[] inputArray){ 
int maxValue = inputArray[0]; 
for(int i=1;i < inputArray.length;i++){ 
  if(inputArray[i] > maxValue){ 
     maxValue = inputArray[i]; 
  } 
} 
return maxValue; 
}

// Method for getting the minimum value
public static int getMin(int[] inputArray){ 
int minValue = inputArray[0]; 
for(int i=1;i<inputArray.length;i++){ 
  if(inputArray[i] < minValue){ 
    minValue = inputArray[i]; 
  } 
} 
return minValue; 
} 
}