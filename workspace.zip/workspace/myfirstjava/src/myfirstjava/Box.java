package myfirstjava;

import java.util.Scanner;

public class Box {

	double depth;
	double width;
	double height;
	double volume;
	
	Box(double cheight, double cwidth, double cdepth){
		this.height = cheight;
		this.depth = cdepth;
		this.width = cwidth;
		
	};

	public double getDepth() {
		return depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	/*
	Box (){
		height = 30;
		width =10;
		depth=20;
	}
	*/
	
	
	double computevolume(){
		volume = depth*height*width;
		return volume;
	};

	void displayvolume(){
		System.out.println(volume);}
	
	
	
	
	

	public static void main(String[] args) {

		Box box = new Box(10 , 50, 100);
		System.out.print(box.computevolume());
		
	}

}
