package myfirstjava;

import java.util.Scanner;

public class question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		
		System.out.print("enter a number 1");
		int one = in.nextInt();
		
		System.out.print("enter a number 2");
		int two = in.nextInt();
		
		for (int i=one; i < two + 1; i++){
			if (i % 2 == 0 ){
				System.out.print(i+ " ");
			}
		}
		
		
	}

}
