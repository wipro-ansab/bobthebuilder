package myfirstjava;

public class TestRect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Rectangle rectangle = new Rectangle();
rectangle.Getdimensions();
rectangle.computearea();
rectangle.displayarea();

	}

}
