package myfirstjava;

import java.util.Scanner;

public class Book {
	String booktitle;
	String author;
	String isbncode;
	double originalprice;
	double finalprice;
	String result;
	public String getBooktitle() {
		return booktitle;
		
	}


	public void setBooktitle(String booktitle) {
		this.booktitle = booktitle;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public String getIsbncode() {
		return isbncode;
	}


	public void setIsbncode(String isbncode) {
		this.isbncode = isbncode;
	}


	public double getOriginalprice() {
		return originalprice;
	}


	public void setOriginalprice(float originalprice) {
		this.originalprice = originalprice;
	}


	public double getFinalprice() {
		return finalprice;
	}


	public void setFinalprice(double finalprice) {
		this.finalprice = finalprice;
	}


	public String getResult() {
		return result;
	}


	public void setResult(String result) {
		this.result = result;
	}

	void getDetails(){
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("booktitle, author, isbncode, originalprice");
		booktitle=scanner.nextLine();
		author=scanner.nextLine();
		isbncode=scanner.next();
		originalprice=scanner.nextDouble();
		
	}
		private Book(String booktitle, String author) {
			  this.booktitle = booktitle;
			  this.author = author;
			  }
public double getdiscountPrice(String nino){
	double discount = originalprice*(10/100);
	finalprice= originalprice - discount;
	setFinalprice(finalprice);
	System.out.println("***"+finalprice+","+discount);
	return originalprice - discount;
}
public double getdiscountPrice(int employeeid){
	double discount = originalprice*(20/100);
	finalprice= originalprice - discount;
	setFinalprice(finalprice);
	System.out.println("***"+finalprice+","+discount);
	return originalprice - discount;
}
public void displaybookdetails(String nino){
	
	
			
		}
		public Book(String booktitle, String author, String isbncode, int originalprice) {
			  this.booktitle = booktitle;
			  this.author = author;
			  this.isbncode = isbncode;
			  this.originalprice = originalprice;
			  }
			
		
	{
		// TODO Auto-generated method stub

	}

}
