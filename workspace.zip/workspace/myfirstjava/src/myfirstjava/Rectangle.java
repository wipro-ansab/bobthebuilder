package myfirstjava;

import java.util.Scanner;

public class Rectangle {
int height;
int length;
int Rarea;

Rectangle(){
	height = 30;
	length =10;
}

void Getdimensions(){
	Scanner in = new Scanner(System.in);
	System.out.println("Enter Height");
	height = in.nextInt();
	System.out.println("Enter Length");
	length = in.nextInt();
	
};
void computearea(){
	Rarea = length*height;
};

void displayarea(){
	System.out.println(Rarea);
};
	
	
}
