package myfirstjava;

public class Question16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] duparray = {1,1,7,2,7,3,3,3,5,6,8};
	}
public int getmodelement(int [] duparray)
{
		int count = 0;
		int storecount;
		int store = 0;
		int mode = duparray[0];
		for (int i= 0; i < (duparray.length -1); i++)
		{
			store = duparray[i];
			storecount = 0;
			for (int j =1; j<duparray.length; j++)
			{
				if(store == duparray[j])
					storecount++;
			}
			if(storecount > count)
			{
				mode = store;
				count = storecount;
			}
		}
		System.out.println(mode);
		return mode;
}
}
