package myfirstjava;

import java.util.Scanner;

public class question9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		
	System.out.print("Enter Number 1-12:");
	int input;
	try{input = in.nextInt();
	}
	catch(Exception e){System.out.print("Invalid Input, Please enter an integer");
	return;}
	
	switch(input)
	{
	case 1:
		System.out.print("January");
	return;
	case 2:
		System.out.print("February");
	return;
	case 3:
		System.out.print("March");
	return;
	case 4:
		System.out.print("April");
	return;
	case 5:
		System.out.print("May");
	return;
	case 6:
		System.out.print("June");
	return;
	case 7:
		System.out.print("July");
	return;
	case 8:
		System.out.print("August");
	return;
	case 9:
		System.out.print("September");
	return;
	case 10:
	System.out.print("October");
	return;
	case 11:
	System.out.print("November");
	return;
	case 12:
	System.out.print("December");
	return;
	default:
		System.out.print("Invalid Number");
		return;
	}

}
}
