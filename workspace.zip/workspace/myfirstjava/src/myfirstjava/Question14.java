package myfirstjava;
import java.util.Scanner;
public class Question14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[]= new int[5];
		x[0] = 7;
		x[1] = 5;
		x[2] = 2;
		x[3] = 9;
		x[4] = 3;
		int num;
		int count = 5;
		int i;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter integer to search");
        num = in.nextInt();
        /* Compare each element of array with num*/
        for (i = 0; i < count ; i++) {
            if(num == x[i]){
               System.out.println(num+" is present at index "+i);
	}
if(i == count){
	System.out.println(num+"-1");
}
}
}
}
