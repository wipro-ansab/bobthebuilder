package myfirstjava;

public class Calculator {

	int num1;
	int num2;
	int power;
	int powerfunc;
	Calculator (int cnum1, int cnum2){
		this.num1 = cnum1;
		this.num2 = cnum2;
	}
public static int power(int num1, int num2){
	int powerfunc = (int) Math.pow(num1, num2);
	return powerfunc;
}
public static int power(double num1, int num2){
	int powerfunc = (int) Math.pow(num1, num2);
	return powerfunc;
}





	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int result = Calculator.power(10, 20);		
		System.out.println(result);
	}

}
