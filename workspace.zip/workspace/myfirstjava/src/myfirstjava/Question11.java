package myfirstjava;

public class Question11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x,y,z;
  x = 2;
  y = 3;
  z = 5;
 int count = 0;
 int number = 1;
  while(count < 5){
	  if(number % x == 0 && number % y == 0&& number % z == 0)
	  {
		  System.out.println(number);
		  count++;
	  }
	  number++;
	}
	}
}