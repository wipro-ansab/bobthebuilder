package myfirstjava;

import java.util.Scanner;

public class question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	Scanner in = new Scanner(System.in);
	
	System.out.print("enter a number 1");
	int one = in.nextInt();
	
	System.out.print("enter a number 2");
	int two = in.nextInt();
	
	for (int i=one; i < two; i++){
		int j;
		for (j=2; j<i; j++){
		int n = i%j;
		if (n==0){
		break;
		}
		}
		if(i == j){
		  
			System.out.print(i+ " ");
		}
	
	}
}
}

	
