package OPP;

public class Testshape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape c = new Circle();
		Shape t = new Triangle();
		Shape s = new Square();
		c.draw();
		t.draw();
		s.draw();
		c.erase();
		t.erase();
		s.erase();
		
	}

}
