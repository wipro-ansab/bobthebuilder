package OPP;

public class Orange extends Fruit {
	public Orange()
	{
		
	}

	public Orange(String name, String taste, int size) {
		super(name, taste, size);
		// TODO Auto-generated constructor stub
	}
	public void Eat (){
		String name = "Orange";
		String taste = "juicy";
		System.out.println("name is "+name + " taste is " + taste);
}
}