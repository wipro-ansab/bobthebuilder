package OPP;

public class Circle extends Shape {
	public Circle(){
		
	}
	
	public void draw()
	{
		System.out.println("Drawing Circle");
	}
	public void erase()
	{
		System.out.println("Erasing Circle");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
