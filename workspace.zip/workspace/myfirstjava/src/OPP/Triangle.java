package OPP;

public class Triangle extends Shape {

public Triangle(){
		
	}
	
	public void draw()
	{
		System.out.println("Drawing Triangle");
	}
	public void erase()
	{
		System.out.println("Erasing Triangle");
	}

	}

