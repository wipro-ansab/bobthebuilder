package OPP;

public class Person {
String name;
int age;
String nationality;

Person (){
	name = "Akusei";
	age = 25;
	nationality ="Dutch";
}
public Person(String name, int age, String nationality) {
	super();
	this.name = name;
	this.age = age;
	this.nationality = nationality;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public int getAge() {
	return age;
}


public void setAge(int age) {
	this.age = age;
}


public String getNationality() {
	return nationality;
}


public void setNationality(String nationality) {
	this.nationality = nationality;
}


public class Student extends Person{
	int studid;
	String schoolname;
	public Student(String name, int age, String nationality, int studid,
			String schoolname) {
		super(name, age, nationality);
		this.studid = studid;
		this.schoolname = schoolname;
	}
	public int getStudid() {
		return studid;
	}
	public void setStudid(int studid) {
		this.studid = studid;
	}
	public String getSchoolname() {
		return schoolname;
	}
	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}
	
}
public static void main(String[] args) {

		
	}
}
	
}