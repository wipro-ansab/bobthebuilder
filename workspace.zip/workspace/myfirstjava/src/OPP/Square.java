package OPP;

public class Square extends Shape {
public Square(){
		
	}
	
	public void draw()
	{
		System.out.println("Drawing Square");
	}
	public void erase()
	{
		System.out.println("Erasing Square");
	}

}
