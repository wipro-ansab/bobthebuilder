package OPP;

public class Testfruit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Fruit t = new Fruit();
Fruit y = new Apple();
Fruit z = new Orange();

t.Eat();
y.Eat();
z.Eat();
	}

}
