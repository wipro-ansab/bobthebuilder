package OPP;

public class Shape {
String name;
	int size;
public Shape(){}

public void draw()
{
	System.out.println("Drawing Circle");
	System.out.println("Drawing Triangle");
	System.out.println("Drawing Square");
}
public void erase()
{
	System.out.println("Erasing Circle");
	System.out.println("Erasing Triangle");
	System.out.println("Erasing Square");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
