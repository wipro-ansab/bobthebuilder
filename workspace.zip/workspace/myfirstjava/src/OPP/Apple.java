package OPP;

public class Apple extends Fruit {

	public Apple()
	{
		
	}
	public Apple(String name, String taste, int size) {
		super(name, taste, size);
		// TODO Auto-generated constructor stub
	}
	public void Eat (){
		String name = "Apple";
		String taste = "Sour";
		System.out.println("name is "+name + " taste is " + taste);

	}
}
