package OPP;

public class Fruit {
String name;
String taste;
int size;
public Fruit()
{
	
}
public Fruit(String name, String taste, int size)
{
	super();
	this.name = name;
	this.taste = taste;
	this.size = size;
}
	public void Eat ()
	{
		String name = "Orange";
		String taste = "juicy";
		System.out.println("name is "+name + "taste is " + taste);
		
}
}
